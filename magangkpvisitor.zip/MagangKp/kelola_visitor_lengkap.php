<?php
/**
 * Admin Visitor Sync Page
 * Data is synchronized with OPAC visitor because both use visitor_count table.
 */

defined('INDEX_AUTH') or die('Direct access not allowed!');

if (!function_exists('do_checkIP')) {
    require LIB . 'ip_based_access.inc.php';
}
do_checkIP('smc');
do_checkIP('smc-reporting');

if (session_status() !== PHP_SESSION_ACTIVE) {
    require SB . 'admin/default/session.inc.php';
}
if (!defined('MAGANGKP_ADMIN_SESSION_CHECKED')) {
    require SB . 'admin/default/session_check.inc.php';
    define('MAGANGKP_ADMIN_SESSION_CHECKED', 1);
}

$can_read = utility::havePrivilege('reporting', 'r');
$can_write = utility::havePrivilege('reporting', 'w');

if (!$can_read) {
    die('<div class="errorBox">' . __('You don\'t have enough privileges to access this area!') . '</div>');
}

if (!function_exists('magangKpAdminHasColumn')) {
    function magangKpAdminHasColumn(mysqli $dbs, string $column, string $table = 'visitor_count'): bool
    {
        $tableEsc = $dbs->escape_string($table);
        if ($query = $dbs->query("SHOW COLUMNS FROM {$tableEsc} LIKE '" . $dbs->escape_string($column) . "'")) {
            $exists = $query->num_rows > 0;
            $query->free_result();
            return $exists;
        }
        return false;
    }
}

if (!function_exists('magangKpAdminSafeDate')) {
    function magangKpAdminSafeDate(string $value, string $fallback): string
    {
        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : $fallback;
    }
}

if (!function_exists('magangKpAdminLocationOptions')) {
    /**
     * Build location filter options from LokasiMaps setting + existing visitor records.
     */
    function magangKpAdminLocationOptions(mysqli $dbs, bool $hasVisitLocation): array
    {
        $options = [];

        if ($settingQuery = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='lokasimaps_locations' LIMIT 1")) {
            if ($settingRow = $settingQuery->fetch_assoc()) {
                $stored = @unserialize($settingRow['setting_value']);
                if (is_array($stored)) {
                    foreach ($stored as $locationRow) {
                        if (!is_array($locationRow)) {
                            continue;
                        }
                        $label = trim(strip_tags((string)($locationRow['label'] ?? '')));
                        if ($label === '') {
                            continue;
                        }
                        $options[$label] = $label;
                    }
                }
            }
            $settingQuery->free_result();
        }

        if ($hasVisitLocation && ($visitQuery = $dbs->query("SELECT DISTINCT TRIM(visit_location) AS visit_location FROM visitor_count WHERE visit_location IS NOT NULL AND TRIM(visit_location) <> '' ORDER BY visit_location ASC"))) {
            while ($visitRow = $visitQuery->fetch_assoc()) {
                $label = trim((string)($visitRow['visit_location'] ?? ''));
                if ($label === '') {
                    continue;
                }
                $options[$label] = $label;
            }
            $visitQuery->free_result();
        }

        return array_values($options);
    }
}

if (!function_exists('magangKpAdminVisitScheduleSettingName')) {
    function magangKpAdminVisitScheduleSettingName(): string
    {
        return 'magangkp_visit_schedule';
    }
}

if (!function_exists('magangKpAdminDayLabels')) {
    function magangKpAdminDayLabels(): array
    {
        return [
            'monday' => 'Senin',
            'tuesday' => 'Selasa',
            'wednesday' => 'Rabu',
            'thursday' => 'Kamis',
            'friday' => 'Jumat',
            'saturday' => 'Sabtu',
            'sunday' => 'Minggu'
        ];
    }
}

if (!function_exists('magangKpAdminDefaultDaySchedule')) {
    function magangKpAdminDefaultDaySchedule(): array
    {
        $defaults = [];
        foreach (array_keys(magangKpAdminDayLabels()) as $dayKey) {
            $defaults[$dayKey] = [
                'open' => 1,
                'open_time' => '08:00',
                'close_time' => '16:00'
            ];
        }
        return $defaults;
    }
}

if (!function_exists('magangKpAdminReadSetting')) {
    function magangKpAdminReadSetting(mysqli $dbs, string $settingName): ?string
    {
        $nameEsc = $dbs->escape_string($settingName);
        if ($query = $dbs->query("SELECT setting_value FROM setting WHERE setting_name='{$nameEsc}' LIMIT 1")) {
            $value = null;
            if ($row = $query->fetch_assoc()) {
                $value = (string)($row['setting_value'] ?? '');
            }
            $query->free_result();
            return $value;
        }
        return null;
    }
}

if (!function_exists('magangKpAdminUpsertSetting')) {
    function magangKpAdminUpsertSetting(mysqli $dbs, string $settingName, string $settingValue): bool
    {
        $nameEsc = $dbs->escape_string($settingName);
        $valueEsc = $dbs->escape_string($settingValue);
        $sql = "INSERT INTO setting (setting_name, setting_value) VALUES ('{$nameEsc}', '{$valueEsc}') "
            . "ON DUPLICATE KEY UPDATE setting_value='{$valueEsc}'";
        return (bool)$dbs->query($sql);
    }
}

if (!function_exists('magangKpAdminNormalizeTime')) {
    function magangKpAdminNormalizeTime(string $value, string $fallback): string
    {
        $value = trim($value);
        if (!preg_match('/^\d{2}:\d{2}$/', $value)) {
            return $fallback;
        }

        $hour = (int)substr($value, 0, 2);
        $minute = (int)substr($value, 3, 2);
        if ($hour < 0 || $hour > 23 || $minute < 0 || $minute > 59) {
            return $fallback;
        }

        return sprintf('%02d:%02d', $hour, $minute);
    }
}

if (!function_exists('magangKpAdminValidDate')) {
    function magangKpAdminValidDate(string $value): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
            return false;
        }
        $dateObj = DateTime::createFromFormat('Y-m-d', $value);
        return $dateObj && $dateObj->format('Y-m-d') === $value;
    }
}

if (!function_exists('magangKpAdminLoadVisitSchedule')) {
    function magangKpAdminLoadVisitSchedule(mysqli $dbs): array
    {
        $rawValue = magangKpAdminReadSetting($dbs, magangKpAdminVisitScheduleSettingName());
        if ($rawValue === null || $rawValue === '') {
            return ['schedules' => [], 'holidays' => []];
        }

        $decoded = @unserialize($rawValue);
        if (!is_array($decoded)) {
            $decoded = json_decode((string)$rawValue, true);
        }
        if (!is_array($decoded)) {
            return ['schedules' => [], 'holidays' => []];
        }

        $dayLabels = magangKpAdminDayLabels();
        $defaultDay = magangKpAdminDefaultDaySchedule();
        $normalized = ['schedules' => [], 'holidays' => []];

        $rawSchedules = is_array($decoded['schedules'] ?? null) ? $decoded['schedules'] : [];
        foreach ($rawSchedules as $location => $dayMap) {
            $locationName = trim(strip_tags((string)$location));
            if ($locationName === '' || !is_array($dayMap)) {
                continue;
            }
            $normalizedDay = $defaultDay;
            foreach ($dayLabels as $dayKey => $dayLabel) {
                $dayConfig = is_array($dayMap[$dayKey] ?? null) ? $dayMap[$dayKey] : [];
                $openRaw = $dayConfig['open'] ?? 0;
                $normalizedDay[$dayKey] = [
                    'open' => ($openRaw === 1 || $openRaw === '1' || $openRaw === true || $openRaw === 'true' || $openRaw === 'on') ? 1 : 0,
                    'open_time' => magangKpAdminNormalizeTime((string)($dayConfig['open_time'] ?? ''), '08:00'),
                    'close_time' => magangKpAdminNormalizeTime((string)($dayConfig['close_time'] ?? ''), '16:00')
                ];
            }
            $normalized['schedules'][$locationName] = $normalizedDay;
        }

        $rawHolidays = is_array($decoded['holidays'] ?? null) ? $decoded['holidays'] : [];
        $seenHoliday = [];
        foreach ($rawHolidays as $holidayRow) {
            if (!is_array($holidayRow)) {
                continue;
            }
            $date = trim((string)($holidayRow['date'] ?? ''));
            if (!magangKpAdminValidDate($date)) {
                continue;
            }

            $name = trim(strip_tags((string)($holidayRow['name'] ?? '')));
            if (function_exists('mb_substr')) {
                $name = mb_substr($name, 0, 120, 'UTF-8');
            } else {
                $name = substr($name, 0, 120);
            }

            $location = trim(strip_tags((string)($holidayRow['location'] ?? 'all')));
            if ($location === '') {
                $location = 'all';
            }

            $key = $date . '|' . $location . '|' . $name;
            if (isset($seenHoliday[$key])) {
                continue;
            }
            $seenHoliday[$key] = true;

            $normalized['holidays'][] = [
                'date' => $date,
                'name' => $name,
                'location' => $location
            ];
        }

        return $normalized;
    }
}

if (!function_exists('magangKpAdminSanitizeScheduleMap')) {
    function magangKpAdminSanitizeScheduleMap(string $rawJson, array $allowedLocations): array
    {
        $decoded = json_decode($rawJson, true);
        if (!is_array($decoded)) {
            return [];
        }

        $dayLabels = magangKpAdminDayLabels();
        $defaultDay = magangKpAdminDefaultDaySchedule();
        $allowedMap = [];
        foreach ($allowedLocations as $location) {
            $label = trim((string)$location);
            if ($label !== '') {
                $allowedMap[$label] = $label;
            }
        }

        $result = [];
        foreach ($decoded as $location => $dayMap) {
            $locationName = trim(strip_tags((string)$location));
            if ($locationName === '' || !isset($allowedMap[$locationName]) || !is_array($dayMap)) {
                continue;
            }

            $normalizedDay = $defaultDay;
            foreach ($dayLabels as $dayKey => $dayLabel) {
                $dayConfig = is_array($dayMap[$dayKey] ?? null) ? $dayMap[$dayKey] : [];
                $openRaw = $dayConfig['open'] ?? 0;
                $normalizedDay[$dayKey] = [
                    'open' => ($openRaw === 1 || $openRaw === '1' || $openRaw === true || $openRaw === 'true' || $openRaw === 'on') ? 1 : 0,
                    'open_time' => magangKpAdminNormalizeTime((string)($dayConfig['open_time'] ?? ''), '08:00'),
                    'close_time' => magangKpAdminNormalizeTime((string)($dayConfig['close_time'] ?? ''), '16:00')
                ];
            }
            $result[$locationName] = $normalizedDay;
        }

        return $result;
    }
}

if (!function_exists('magangKpAdminSanitizeHolidays')) {
    function magangKpAdminSanitizeHolidays(array $holidayDates, array $holidayNames, array $holidayLocations, array $allowedLocations): array
    {
        $allowedMap = ['all' => 'all'];
        foreach ($allowedLocations as $location) {
            $label = trim((string)$location);
            if ($label !== '') {
                $allowedMap[$label] = $label;
            }
        }

        $total = max(count($holidayDates), count($holidayNames), count($holidayLocations));
        $result = [];
        $seen = [];

        for ($i = 0; $i < $total; $i++) {
            $date = trim((string)($holidayDates[$i] ?? ''));
            if (!magangKpAdminValidDate($date)) {
                continue;
            }

            $name = trim(strip_tags((string)($holidayNames[$i] ?? '')));
            if (function_exists('mb_substr')) {
                $name = mb_substr($name, 0, 120, 'UTF-8');
            } else {
                $name = substr($name, 0, 120);
            }

            $location = trim(strip_tags((string)($holidayLocations[$i] ?? 'all')));
            if (!isset($allowedMap[$location])) {
                $location = 'all';
            }

            $key = $date . '|' . $location . '|' . $name;
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;

            $result[] = [
                'date' => $date,
                'name' => $name,
                'location' => $location
            ];
        }

        usort($result, static function (array $a, array $b): int {
            return strcmp($a['date'], $b['date']);
        });

        return $result;
    }
}

$pluginId = utility::filterData('id', 'get', false, true, true);
$basePageUrl = AWB . 'plugin_container.php';
$today = date('Y-m-d');

$dateFrom = magangKpAdminSafeDate(utility::filterData('date_from', 'get', false, true, true) ?: $today, $today);
$dateUntil = magangKpAdminSafeDate(utility::filterData('date_until', 'get', false, true, true) ?: $today, $today);
if (strtotime($dateUntil) < strtotime($dateFrom)) {
    $temp = $dateFrom;
    $dateFrom = $dateUntil;
    $dateUntil = $temp;
}

$keyword = utility::filterData('keyword', 'get', true, true, true) ?? '';
$keyword = trim($keyword);

$showAllDates = (string)(utility::filterData('all_dates', 'get', false, true, true) ?? '') === '1';

$visitorTypeFilter = utility::filterData('visitor_type', 'get', false, true, true) ?: 'all';
$allowedVisitorTypes = ['all', 'member', 'non_member', 'rombongan'];
if (!in_array($visitorTypeFilter, $allowedVisitorTypes, true)) {
    $visitorTypeFilter = 'all';
}

$visitLocationFilter = utility::filterData('visit_location', 'get', true, true, true) ?? 'all';
$visitLocationFilter = trim((string)$visitLocationFilter);
if ($visitLocationFilter === '') {
    $visitLocationFilter = 'all';
}

$perPage = (int)(utility::filterData('per_page', 'get', false, true, true) ?: 20);
if ($perPage < 20) {
    $perPage = 20;
}
if ($perPage > 200) {
    $perPage = 200;
}

$page = (int)(utility::filterData('page', 'get', false, true, true) ?: 1);
if ($page < 1) {
    $page = 1;
}

$hasGroupCount = magangKpAdminHasColumn($dbs, 'group_count');
$hasVisitorType = magangKpAdminHasColumn($dbs, 'visitor_type');
$hasVisitorPurpose = magangKpAdminHasColumn($dbs, 'visitor_purpose');
$hasGroupPurpose = magangKpAdminHasColumn($dbs, 'group_purpose');
$hasVisitorGender = magangKpAdminHasColumn($dbs, 'visitor_gender');
$hasMemberGender = magangKpAdminHasColumn($dbs, 'gender', 'member');
$hasMemberTypeId = magangKpAdminHasColumn($dbs, 'member_type_id', 'member');
$hasMemberTypeTable = false;
if ($tableCheck = $dbs->query("SHOW TABLES LIKE 'mst_member_type'")) {
    $hasMemberTypeTable = $tableCheck->num_rows > 0;
    $tableCheck->free_result();
}
$hasMemberTypeName = $hasMemberTypeTable
    ? magangKpAdminHasColumn($dbs, 'member_type_name', 'mst_member_type')
    : false;
$hasGroupMale = magangKpAdminHasColumn($dbs, 'group_gender_male');
$hasGroupFemale = magangKpAdminHasColumn($dbs, 'group_gender_female');
$hasVisitLocation = magangKpAdminHasColumn($dbs, 'visit_location');
$visitLocationOptions = magangKpAdminLocationOptions($dbs, $hasVisitLocation);
if (count($visitLocationOptions) < 1) {
    $fallbackLocation = trim(strip_tags((string)($sysconf['library_name'] ?? 'Lokasi Utama')));
    if ($fallbackLocation !== '') {
        $visitLocationOptions[] = $fallbackLocation;
    }
}

$weightExpr = $hasGroupCount
    ? "CASE WHEN vc.group_count IS NULL OR vc.group_count < 1 THEN 1 ELSE vc.group_count END"
    : "1";

$resolvedTypeExpr = $hasVisitorType
    ? "CASE
        WHEN COALESCE(vc.visitor_type, '') <> '' THEN vc.visitor_type
        WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
        WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
        ELSE 'non_member'
      END"
    : "CASE
        WHEN COALESCE(vc.member_id, '') <> '' THEN 'member'
        WHEN COALESCE(vc.member_name, '') LIKE '%Rombongan%' THEN 'rombongan'
        ELSE 'non_member'
      END";

$purposeExpr = "'Belum diisi'";
if ($hasVisitorPurpose && $hasGroupPurpose) {
    $purposeExpr = "CASE
      WHEN {$resolvedTypeExpr} = 'rombongan'
        THEN COALESCE(NULLIF(TRIM(vc.group_purpose), ''), NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')
      ELSE COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')
    END";
} elseif ($hasVisitorPurpose) {
    $purposeExpr = "COALESCE(NULLIF(TRIM(vc.visitor_purpose), ''), 'Belum diisi')";
} elseif ($hasGroupPurpose) {
    $purposeExpr = "COALESCE(NULLIF(TRIM(vc.group_purpose), ''), 'Belum diisi')";
}

$maleSingleExpr = $hasVisitorGender
    ? "CASE
        WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('1', 'laki laki', 'laki', 'pria', 'male', 'l', 'm') THEN 1
        ELSE 0
      END"
    : "0";
$femaleSingleExpr = $hasVisitorGender
    ? "CASE
        WHEN LOWER(REPLACE(TRIM(COALESCE(vc.visitor_gender, '')), '-', ' ')) IN ('0', 'perempuan', 'wanita', 'female', 'p', 'f') THEN 1
        ELSE 0
      END"
    : "0";
$maleMemberExpr = $hasMemberGender
    ? "CASE WHEN COALESCE(CAST(m.gender AS CHAR), '') IN ('1', 'male', 'Male', 'M', 'm') THEN 1 ELSE 0 END"
    : "0";
$femaleMemberExpr = $hasMemberGender
    ? "CASE WHEN COALESCE(CAST(m.gender AS CHAR), '') IN ('0', 'female', 'Female', 'F', 'f') THEN 1 ELSE 0 END"
    : "0";
$maleExpr = "CASE
    WHEN {$resolvedTypeExpr} = 'rombongan' THEN " . ($hasGroupMale ? "COALESCE(vc.group_gender_male, 0)" : "0") . "
    WHEN {$resolvedTypeExpr} = 'member' THEN {$maleMemberExpr}
    WHEN {$resolvedTypeExpr} = 'non_member' THEN {$maleSingleExpr}
    ELSE 0
  END";
$femaleExpr = "CASE
    WHEN {$resolvedTypeExpr} = 'rombongan' THEN " . ($hasGroupFemale ? "COALESCE(vc.group_gender_female, 0)" : "0") . "
    WHEN {$resolvedTypeExpr} = 'member' THEN {$femaleMemberExpr}
    WHEN {$resolvedTypeExpr} = 'non_member' THEN {$femaleSingleExpr}
    ELSE 0
  END";
$visitLocationExpr = $hasVisitLocation
    ? "COALESCE(NULLIF(TRIM(vc.visit_location), ''), '-')"
    : "'-'";
$memberTypeExpr = ($hasMemberTypeId && $hasMemberTypeTable && $hasMemberTypeName)
    ? "COALESCE(NULLIF(TRIM(mt.member_type_name), ''), '-')"
    : "'-'";
$memberTypeJoinSql = ($hasMemberTypeId && $hasMemberTypeTable && $hasMemberTypeName)
    ? "LEFT JOIN mst_member_type mt ON mt.member_type_id = m.member_type_id"
    : "";

$baseQuery = [
    'mod' => 'reporting',
    'id' => $pluginId,
    'date_from' => $dateFrom,
    'date_until' => $dateUntil,
    'all_dates' => $showAllDates ? 1 : null,
    'keyword' => $keyword,
    'visitor_type' => $visitorTypeFilter,
    'visit_location' => $visitLocationFilter,
    'per_page' => $perPage
];

$buildUrl = function (array $overrides = []) use ($baseQuery, $basePageUrl) {
    $query = array_merge($baseQuery, $overrides);
    foreach ($query as $key => $value) {
        if ($value === null || $value === '') {
            unset($query[$key]);
        }
    }
    return $basePageUrl . (empty($query) ? '' : ('?' . http_build_query($query)));
};

$dayLabels = magangKpAdminDayLabels();
$visitScheduleConfig = magangKpAdminLoadVisitSchedule($dbs);
$visitSchedules = is_array($visitScheduleConfig['schedules'] ?? null) ? $visitScheduleConfig['schedules'] : [];
$visitHolidays = is_array($visitScheduleConfig['holidays'] ?? null) ? $visitScheduleConfig['holidays'] : [];

$flashType = '';
$flashMessage = '';

if (isset($_POST['save_visit_schedule'])) {
    if (!$can_write) {
        $flashType = 'danger';
        $flashMessage = __('You don\'t have enough privileges to modify visitor schedule!');
    } else {
        $rawScheduleMap = (string)($_POST['schedule_map_json'] ?? '');
        $sanitizedSchedules = magangKpAdminSanitizeScheduleMap($rawScheduleMap, $visitLocationOptions);
        $sanitizedHolidays = magangKpAdminSanitizeHolidays(
            is_array($_POST['holiday_date'] ?? null) ? $_POST['holiday_date'] : [],
            is_array($_POST['holiday_name'] ?? null) ? $_POST['holiday_name'] : [],
            is_array($_POST['holiday_location'] ?? null) ? $_POST['holiday_location'] : [],
            $visitLocationOptions
        );

        $payload = [
            'version' => 1,
            'updated_at' => date('Y-m-d H:i:s'),
            'schedules' => $sanitizedSchedules,
            'holidays' => $sanitizedHolidays
        ];

        $saved = magangKpAdminUpsertSetting($dbs, magangKpAdminVisitScheduleSettingName(), serialize($payload));
        if ($saved) {
            utility::loadSettings($dbs);
            $visitScheduleConfig = magangKpAdminLoadVisitSchedule($dbs);
            $visitSchedules = is_array($visitScheduleConfig['schedules'] ?? null) ? $visitScheduleConfig['schedules'] : [];
            $visitHolidays = is_array($visitScheduleConfig['holidays'] ?? null) ? $visitScheduleConfig['holidays'] : [];
            $flashType = 'success';
            $flashMessage = 'Jadwal visitor berhasil disimpan.';
        } else {
            $flashType = 'danger';
            $flashMessage = 'Gagal menyimpan jadwal visitor.';
        }
    }
}

$isDeleteRequest = $_SERVER['REQUEST_METHOD'] === 'POST'
    && (
        isset($_POST['delete_selected'])
        || isset($_POST['visitor_ids'])
        || isset($_POST['itemID'])
    );

if ($isDeleteRequest) {
    if (!$can_write) {
        $flashType = 'danger';
        $flashMessage = __('You don\'t have enough privileges to modify visitor data!');
    } else {
        $selectedIds = $_POST['visitor_ids'] ?? [];
        if (!is_array($selectedIds)) {
            $selectedIds = [$selectedIds];
        }

        // Compatibility fallback if selection comes from datagrid style payload.
        if (isset($_POST['itemID'])) {
            $itemIds = $_POST['itemID'];
            if (!is_array($itemIds)) {
                $itemIds = [$itemIds];
            }
            foreach ($itemIds as $itemId) {
                $selectedIds[] = $itemId;
            }
        }

        $safeIds = [];
        foreach ($selectedIds as $selectedId) {
            if (is_string($selectedId) && strpos($selectedId, ',') !== false) {
                $splitIds = explode(',', $selectedId);
                foreach ($splitIds as $splitId) {
                    $id = (int)$splitId;
                    if ($id > 0) {
                        $safeIds[$id] = $id;
                    }
                }
                continue;
            }
            $id = (int)$selectedId;
            if ($id > 0) {
                $safeIds[$id] = $id;
            }
        }
        $safeIds = array_values($safeIds);

        if (empty($safeIds)) {
            $flashType = 'warning';
            $flashMessage = __('No visitor data selected.');
        } else {
            // Expand selected ids: if a selected row belongs to rombongan,
            // remove the whole rombongan batch for that check-in session.
            $expandedIds = $safeIds;
            $selectedIdList = implode(',', $safeIds);

            $selectedRowsSql = "
                SELECT
                  vc.visitor_id,
                  {$resolvedTypeExpr} AS visitor_type_resolved,
                  COALESCE(vc.institution, '') AS institution,
                  COALESCE(vc.checkin_date, '') AS checkin_date" . ($hasVisitLocation ? ",
                  COALESCE(vc.visit_location, '') AS visit_location" : ",
                  '' AS visit_location") . "
                FROM visitor_count vc
                WHERE vc.visitor_id IN ({$selectedIdList})
            ";

            if ($selectedRowsResult = $dbs->query($selectedRowsSql)) {
                while ($selectedRow = $selectedRowsResult->fetch_assoc()) {
                    $resolvedType = (string)($selectedRow['visitor_type_resolved'] ?? '');
                    if ($resolvedType !== 'rombongan') {
                        continue;
                    }

                    $checkinDate = trim((string)($selectedRow['checkin_date'] ?? ''));
                    $institution = trim((string)($selectedRow['institution'] ?? ''));
                    $visitLocation = trim((string)($selectedRow['visit_location'] ?? ''));
                    if ($checkinDate === '') {
                        continue;
                    }

                    $checkinEsc = $dbs->escape_string($checkinDate);
                    $institutionEsc = $dbs->escape_string($institution);
                    $groupWhere = [];
                    if ($hasVisitorType) {
                        $groupWhere[] = "(COALESCE(vc2.visitor_type, '') = 'rombongan' OR (COALESCE(vc2.visitor_type, '') = '' AND COALESCE(vc2.member_name, '') LIKE '%Rombongan%'))";
                    } else {
                        $groupWhere[] = "COALESCE(vc2.member_name, '') LIKE '%Rombongan%'";
                    }
                    $groupWhere[] = "vc2.checkin_date = '{$checkinEsc}'";
                    $groupWhere[] = "COALESCE(vc2.institution, '') = '{$institutionEsc}'";

                    if ($hasVisitLocation) {
                        $visitLocationEsc = $dbs->escape_string($visitLocation);
                        $groupWhere[] = "COALESCE(vc2.visit_location, '') = '{$visitLocationEsc}'";
                    }

                    $groupWhereSql = implode(' AND ', $groupWhere);
                    $groupRowsSql = "SELECT vc2.visitor_id FROM visitor_count vc2 WHERE {$groupWhereSql}";
                    if ($groupRowsResult = $dbs->query($groupRowsSql)) {
                        while ($groupRow = $groupRowsResult->fetch_assoc()) {
                            $groupId = (int)($groupRow['visitor_id'] ?? 0);
                            if ($groupId > 0) {
                                $expandedIds[$groupId] = $groupId;
                            }
                        }
                        $groupRowsResult->free();
                    }
                }
                $selectedRowsResult->free();
            }

            $expandedIds = array_values($expandedIds);
            $idList = implode(',', $expandedIds);
            $deleted = $dbs->query("DELETE FROM visitor_count WHERE visitor_id IN ({$idList})");
            $affectedRows = (int)$dbs->affected_rows;

            if ($deleted) {
                if ($affectedRows > 0) {
                    $flashType = 'success';
                    $flashMessage = str_replace('{amount}', (string)$affectedRows, __('Successfully deleted {amount} visitor record(s).'));
                } else {
                    $flashType = 'warning';
                    $flashMessage = 'Data tidak terhapus. Kemungkinan data sudah dihapus sebelumnya.';
                }
            } else {
                $flashType = 'danger';
                $flashMessage = __('Failed to delete selected visitor data.') . ' DB: ' . $dbs->error;
            }
        }
    }
}

$where = [];
if (!$showAllDates) {
    $where[] = "vc.checkin_date >= '" . $dbs->escape_string($dateFrom . ' 00:00:00') . "'";
    $where[] = "vc.checkin_date <= '" . $dbs->escape_string($dateUntil . ' 23:59:59') . "'";
}

if ($keyword !== '') {
    $keywordEscaped = $dbs->escape_string($keyword);
    $where[] = "(vc.member_id LIKE '%{$keywordEscaped}%' OR vc.member_name LIKE '%{$keywordEscaped}%' OR vc.institution LIKE '%{$keywordEscaped}%'"
        . ($hasVisitLocation ? " OR vc.visit_location LIKE '%{$keywordEscaped}%'" : '')
        . ")";
}

if ($visitorTypeFilter !== 'all') {
    $where[] = "{$resolvedTypeExpr} = '" . $dbs->escape_string($visitorTypeFilter) . "'";
}

if ($hasVisitLocation && $visitLocationFilter !== 'all') {
    $where[] = "TRIM(COALESCE(vc.visit_location, '')) = '" . $dbs->escape_string($visitLocationFilter) . "'";
}

$whereSql = implode(' AND ', $where);
if ($whereSql === '') {
    $whereSql = '1=1';
}

$summary = [
    'row_total' => 0,
    'person_total' => 0,
    'member_total' => 0,
    'non_member_total' => 0,
    'rombongan_total' => 0
];

$summarySql = "
    SELECT
      COUNT(vc.visitor_id) AS row_total,
      COALESCE(SUM({$weightExpr}), 0) AS person_total,
      COALESCE(SUM(CASE WHEN {$resolvedTypeExpr} = 'member' THEN {$weightExpr} ELSE 0 END), 0) AS member_total,
      COALESCE(SUM(CASE WHEN {$resolvedTypeExpr} = 'non_member' THEN {$weightExpr} ELSE 0 END), 0) AS non_member_total,
      COALESCE(SUM(CASE WHEN {$resolvedTypeExpr} = 'rombongan' THEN {$weightExpr} ELSE 0 END), 0) AS rombongan_total
    FROM visitor_count vc
    WHERE {$whereSql}
";

if ($summaryResult = $dbs->query($summarySql)) {
    if ($summaryRow = $summaryResult->fetch_assoc()) {
        $summary['row_total'] = (int)$summaryRow['row_total'];
        $summary['person_total'] = (int)$summaryRow['person_total'];
        $summary['member_total'] = (int)$summaryRow['member_total'];
        $summary['non_member_total'] = (int)$summaryRow['non_member_total'];
        $summary['rombongan_total'] = (int)$summaryRow['rombongan_total'];
    }
    $summaryResult->free();
}

$totalRows = max(0, (int)$summary['row_total']);
$totalPages = max(1, (int)ceil(($totalRows > 0 ? $totalRows : 1) / $perPage));
if ($page > $totalPages) {
    $page = $totalPages;
}
$offset = ($page - 1) * $perPage;

$rows = [];
$listSql = "
    SELECT
      vc.visitor_id,
      vc.checkin_date,
      COALESCE(vc.member_id, '') AS member_id,
      COALESCE(vc.member_name, '') AS member_name,
      COALESCE(vc.institution, '') AS institution,
      {$visitLocationExpr} AS visit_location,
      {$resolvedTypeExpr} AS visitor_type_resolved,
      {$purposeExpr} AS purpose_resolved,
      {$memberTypeExpr} AS member_type_display,
      {$weightExpr} AS person_total,
      {$maleExpr} AS male_total,
      {$femaleExpr} AS female_total
    FROM visitor_count vc
    LEFT JOIN member m ON m.member_id = vc.member_id
    {$memberTypeJoinSql}
    WHERE {$whereSql}
    ORDER BY vc.checkin_date DESC, vc.visitor_id DESC
    LIMIT {$offset}, {$perPage}
";

if ($listResult = $dbs->query($listSql)) {
    while ($row = $listResult->fetch_assoc()) {
        $rows[] = $row;
    }
    $listResult->free();
}
?>

<style>
  .magangkp-admin-wrap {
    width: 100%;
  }
  .magangkp-admin-wrap .menuBoxInner {
    width: 100%;
    box-sizing: border-box;
    padding: 20px 22px;
  }
  .magangkp-admin-wrap .mkp-filter-row,
  .magangkp-admin-wrap .mkp-summary-row {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin: 0;
  }
  .magangkp-admin-wrap .mkp-filter-row > [class*="col-"] {
    padding: 0;
    margin: 0;
    flex: 1 1 220px;
    min-width: 220px;
    max-width: none;
  }
  .magangkp-admin-wrap .mkp-filter-row .mkp-filter-submit {
    flex: 0 0 170px;
    min-width: 170px;
  }
  .magangkp-admin-wrap .mkp-filter-row .mkp-filter-full {
    flex: 1 0 100%;
    min-width: 100%;
  }
  .magangkp-admin-wrap .mkp-filter-row label {
    margin-bottom: 6px;
    font-weight: 600;
  }
  .magangkp-admin-wrap .mkp-summary-row > [class*="col-"] {
    padding: 0;
    margin: 0;
    flex: 1 1 170px;
    min-width: 170px;
    max-width: none;
  }
  .magangkp-admin-wrap .mkp-list-toolbar {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
  }
  .magangkp-admin-wrap .mkp-list-toolbar h5 {
    margin: 0;
    padding-top: 2px;
  }
  .magangkp-admin-wrap .card-stat {
    border-radius: 12px;
    border: 1px solid #dbe6ef;
    background: #fff;
    padding: 14px;
    text-align: center;
  }
  .magangkp-admin-wrap .card-stat small {
    display: block;
    color: #5c6b7a;
    font-size: 11px;
    letter-spacing: .4px;
  }
  .magangkp-admin-wrap .card-stat strong {
    display: block;
    font-size: 28px;
    line-height: 1.1;
    color: #0f172a;
    margin-top: 4px;
  }
  .magangkp-admin-wrap .table td,
  .magangkp-admin-wrap .table th {
    vertical-align: middle;
  }
  .magangkp-admin-wrap .badge {
    font-size: 11px;
    padding: 5px 8px;
  }
  .magangkp-admin-wrap .table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
  }
  .magangkp-admin-wrap .table {
    min-width: 1120px;
  }
  .magangkp-admin-wrap .mkp-schedule-card {
    margin-top: 22px;
    border: 1px solid #dbe6ef;
    border-radius: 12px;
    background: #ffffff;
    padding: 16px;
  }
  .magangkp-admin-wrap .mkp-schedule-title {
    margin-bottom: 10px;
  }
  .magangkp-admin-wrap .mkp-schedule-title h5 {
    margin: 0 0 3px;
  }
  .magangkp-admin-wrap .mkp-schedule-title p {
    margin: 0;
    color: #5c6b7a;
  }
  .magangkp-admin-wrap .mkp-schedule-day-table {
    min-width: 650px;
  }
  .magangkp-admin-wrap .mkp-schedule-day-table td,
  .magangkp-admin-wrap .mkp-schedule-day-table th {
    white-space: nowrap;
  }
  .magangkp-admin-wrap .mkp-schedule-day-table .form-control[type="time"] {
    min-width: 120px;
  }
  .magangkp-admin-wrap .mkp-holiday-table {
    min-width: 700px;
  }
  .magangkp-admin-wrap .mkp-holiday-table .mkp-holiday-remove {
    white-space: nowrap;
  }
  .magangkp-admin-wrap .mkp-schedule-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 10px;
  }
  @media (max-width: 767px) {
    .magangkp-admin-wrap .menuBoxInner {
      padding: 14px;
    }
    .magangkp-admin-wrap .mkp-filter-row > [class*="col-"],
    .magangkp-admin-wrap .mkp-summary-row > [class*="col-"] {
      flex: 1 0 100%;
      min-width: 100%;
    }
    .magangkp-admin-wrap .mkp-filter-row .mkp-filter-submit {
      flex: 1 0 100%;
      min-width: 100%;
    }
    .magangkp-admin-wrap .mkp-list-toolbar .btn {
      width: 100%;
    }
    .magangkp-admin-wrap .mkp-schedule-day-table,
    .magangkp-admin-wrap .mkp-holiday-table {
      min-width: 560px;
    }
  }
</style>

<div class="menuBox magangkp-admin-wrap">
  <div class="menuBoxInner">
    <div class="per_title mb-2">
      <h2>Kelola Visitor Lengkap</h2>
    </div>
    <div class="infoBox mb-2">
      <?php echo __('Data visitor admin sinkron otomatis dengan halaman visitor OPAC karena menggunakan tabel visitor_count yang sama.'); ?>
    </div>
    <div class="mb-3">
      <a class="btn btn-light btn-sm mr-1" href="<?php echo AWB . 'modules/reporting/customs/visitor_list.php'; ?>"><?php echo __('Open Native Visitor List'); ?></a>
      <a class="btn btn-light btn-sm" href="<?php echo AWB . 'modules/reporting/customs/visitor_report.php'; ?>"><?php echo __('Open Native Visitor Statistic'); ?></a>
    </div>

    <?php if ($flashMessage !== '') { ?>
      <div class="alert alert-<?php echo $flashType ?: 'info'; ?>">
        <?php echo $flashMessage; ?>
      </div>
    <?php } ?>

    <form method="get" action="<?php echo $basePageUrl; ?>" class="mb-3">
      <input type="hidden" name="mod" value="reporting">
      <input type="hidden" name="id" value="<?php echo htmlspecialchars((string)$pluginId); ?>">
      <div class="form-row align-items-end mkp-filter-row">
        <div class="col-md-2">
          <label><?php echo __('Date From'); ?></label>
          <input type="date" name="date_from" class="form-control" value="<?php echo $dateFrom; ?>">
        </div>
        <div class="col-md-2">
          <label><?php echo __('Date Until'); ?></label>
          <input type="date" name="date_until" class="form-control" value="<?php echo $dateUntil; ?>">
        </div>
        <div class="col-md-3">
          <label><?php echo __('Keyword'); ?></label>
          <input type="text" name="keyword" class="form-control" value="<?php echo htmlspecialchars($keyword); ?>" placeholder="<?php echo __('ID / Name / Institution'); ?> / Lokasi">
        </div>
        <div class="col-md-2">
          <label><?php echo __('Visitor Type'); ?></label>
          <select name="visitor_type" class="form-control">
            <option value="all"<?php echo $visitorTypeFilter === 'all' ? ' selected' : ''; ?>><?php echo __('All'); ?></option>
            <option value="member"<?php echo $visitorTypeFilter === 'member' ? ' selected' : ''; ?>><?php echo __('Member'); ?></option>
            <option value="non_member"<?php echo $visitorTypeFilter === 'non_member' ? ' selected' : ''; ?>><?php echo __('Non Member'); ?></option>
            <option value="rombongan"<?php echo $visitorTypeFilter === 'rombongan' ? ' selected' : ''; ?>>Rombongan</option>
          </select>
        </div>
        <div class="col-md-2">
          <label>Lokasi Kunjungan</label>
          <select name="visit_location" class="form-control">
            <option value="all"<?php echo $visitLocationFilter === 'all' ? ' selected' : ''; ?>>Semua Lokasi</option>
            <?php foreach ($visitLocationOptions as $locationOption) { ?>
              <option value="<?php echo htmlspecialchars($locationOption); ?>"<?php echo $visitLocationFilter === $locationOption ? ' selected' : ''; ?>><?php echo htmlspecialchars($locationOption); ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-1">
          <label><?php echo __('Rows'); ?></label>
          <select name="per_page" class="form-control">
            <?php foreach ([20, 50, 100, 200] as $rowOption) { ?>
              <option value="<?php echo $rowOption; ?>"<?php echo $perPage === $rowOption ? ' selected' : ''; ?>><?php echo $rowOption; ?></option>
            <?php } ?>
          </select>
        </div>
        <div class="col-md-2 mkp-filter-submit">
          <button type="submit" class="btn btn-primary btn-block"><?php echo __('Filter'); ?></button>
        </div>
        <div class="col-md-12 mt-2 mkp-filter-full">
          <label class="mb-0">
            <input type="checkbox" name="all_dates" value="1"<?php echo $showAllDates ? ' checked' : ''; ?>>
            Tampilkan semua tanggal (abaikan Date From/Date Until)
          </label>
        </div>
      </div>
    </form>

    <div class="row mb-3 mkp-summary-row">
      <div class="col-md-3 mb-2"><div class="card-stat"><small><?php echo __('Total Row'); ?></small><strong><?php echo number_format($summary['row_total']); ?></strong></div></div>
      <div class="col-md-3 mb-2"><div class="card-stat"><small><?php echo __('Total Visitor'); ?></small><strong><?php echo number_format($summary['person_total']); ?></strong></div></div>
      <div class="col-md-2 mb-2"><div class="card-stat"><small><?php echo __('Member'); ?></small><strong><?php echo number_format($summary['member_total']); ?></strong></div></div>
      <div class="col-md-2 mb-2"><div class="card-stat"><small><?php echo __('Non Member'); ?></small><strong><?php echo number_format($summary['non_member_total']); ?></strong></div></div>
      <div class="col-md-2 mb-2"><div class="card-stat"><small>Rombongan</small><strong><?php echo number_format($summary['rombongan_total']); ?></strong></div></div>
    </div>

    <form method="post" action="<?php echo $buildUrl(['page' => $page]); ?>">
      <input type="hidden" name="delete_selected" value="1">
      <div class="d-flex justify-content-between align-items-center mb-2 mkp-list-toolbar">
        <h5 class="mb-0"><?php echo __('Visitor List'); ?></h5>
        <?php if ($can_write) { ?>
          <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo __('Delete selected visitor data?'); ?>');">
            <?php echo __('Delete Selected'); ?>
          </button>
        <?php } ?>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-bordered">
          <thead class="thead-light">
            <tr>
              <?php if ($can_write) { ?><th style="width:38px"><input type="checkbox" onclick="var checked=this.checked;var nodes=document.querySelectorAll('.mkp-visitor-check');for(var i=0;i<nodes.length;i++){nodes[i].checked=checked;}"></th><?php } ?>
              <th style="width:70px">ID</th>
              <th style="width:155px"><?php echo __('Check In'); ?></th>
              <th style="width:135px"><?php echo __('Visitor Type'); ?></th>
              <th style="width:150px">Type Member</th>
              <th><?php echo __('Member ID / Visitor Name'); ?></th>
              <th><?php echo __('Institution'); ?></th>
              <th>Lokasi Kunjungan</th>
              <th><?php echo __('Purpose'); ?></th>
              <th style="width:90px"><?php echo __('Total'); ?></th>
              <th style="width:95px">L / P</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($rows)) { ?>
              <tr>
                <td colspan="<?php echo $can_write ? 11 : 10; ?>" class="text-center text-muted"><?php echo __('No visitor data found for current filter.'); ?></td>
              </tr>
            <?php } else { ?>
              <?php foreach ($rows as $row) { ?>
                <?php
                $resolvedType = (string)($row['visitor_type_resolved'] ?? 'non_member');
                $badgeClass = 'badge-secondary';
                if ($resolvedType === 'member') $badgeClass = 'badge-success';
                if ($resolvedType === 'non_member') $badgeClass = 'badge-warning';
                if ($resolvedType === 'rombongan') $badgeClass = 'badge-info';
                $memberId = trim((string)($row['member_id'] ?? ''));
                $memberName = trim((string)($row['member_name'] ?? ''));
                $displayName = $memberName !== '' ? $memberName : ($memberId !== '' ? $memberId : 'Tanpa Nama');
                $memberTypeDisplay = trim((string)($row['member_type_display'] ?? '-'));
                if ($memberTypeDisplay === '' || $resolvedType !== 'member') {
                  $memberTypeDisplay = '-';
                }
                $maleTotal = (int)($row['male_total'] ?? 0);
                $femaleTotal = (int)($row['female_total'] ?? 0);
                ?>
                <tr>
                  <?php if ($can_write) { ?>
                    <td><input class="mkp-visitor-check" type="checkbox" name="visitor_ids[]" value="<?php echo (int)$row['visitor_id']; ?>"></td>
                  <?php } ?>
                  <td><?php echo (int)$row['visitor_id']; ?></td>
                  <td><?php echo htmlspecialchars((string)$row['checkin_date']); ?></td>
                  <td><span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($resolvedType); ?></span></td>
                  <td><?php echo htmlspecialchars($memberTypeDisplay); ?></td>
                  <td>
                    <strong><?php echo htmlspecialchars($displayName); ?></strong>
                    <?php if ($memberId !== '') { ?>
                      <div class="small text-muted"><?php echo __('Member ID'); ?>: <?php echo htmlspecialchars($memberId); ?></div>
                    <?php } ?>
                  </td>
                  <td><?php echo htmlspecialchars((string)($row['institution'] ?? '')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['visit_location'] ?? '-')); ?></td>
                  <td><?php echo htmlspecialchars((string)($row['purpose_resolved'] ?? 'Belum diisi')); ?></td>
                  <td><?php echo (int)($row['person_total'] ?? 1); ?></td>
                  <td><?php echo $maleTotal; ?> / <?php echo $femaleTotal; ?></td>
                </tr>
              <?php } ?>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </form>

    <?php if (false) { ?>
    <?php
    $scheduleLocations = array_values($visitLocationOptions);
    $scheduleLocationsJson = json_encode($scheduleLocations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $scheduleMapJson = json_encode($visitSchedules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $defaultDayScheduleJson = json_encode(magangKpAdminDefaultDaySchedule(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    ?>
    <div class="mkp-schedule-card">
      <div class="mkp-schedule-title">
        <h5>Jadwal Visitor per Lokasi</h5>
        <p>Atur jam buka/tutup per hari sesuai Location Name dan tambahkan hari libur. Saat jam tutup/libur, tombol Add di halaman visitor akan nonaktif otomatis.</p>
      </div>

      <form method="post" action="<?php echo $buildUrl(['page' => $page]); ?>" id="mkpScheduleForm">
        <input type="hidden" name="save_visit_schedule" value="1">
        <input type="hidden" name="schedule_map_json" id="mkpScheduleMapJson" value="">

        <div class="form-row mkp-filter-row">
          <div class="col-md-4">
            <label for="mkpScheduleLocationPicker">Location Name</label>
            <select id="mkpScheduleLocationPicker" class="form-control"<?php echo $can_write ? '' : ' disabled'; ?>></select>
          </div>
        </div>

        <div class="table-responsive">
          <table class="table table-bordered mkp-schedule-day-table">
            <thead class="thead-light">
              <tr>
                <th>Hari</th>
                <th>Status</th>
                <th>Jam Buka</th>
                <th>Jam Tutup</th>
              </tr>
            </thead>
            <tbody id="mkpScheduleDayRows">
              <?php foreach ($dayLabels as $dayKey => $dayLabel) { ?>
                <tr data-day="<?php echo htmlspecialchars($dayKey); ?>">
                  <td><strong><?php echo htmlspecialchars($dayLabel); ?></strong></td>
                  <td>
                    <label class="mb-0">
                      <input type="checkbox" class="mkp-day-open"<?php echo $can_write ? '' : ' disabled'; ?>> Buka
                    </label>
                  </td>
                  <td>
                    <input type="time" class="form-control mkp-day-open-time" value="08:00"<?php echo $can_write ? '' : ' disabled'; ?>>
                  </td>
                  <td>
                    <input type="time" class="form-control mkp-day-close-time" value="16:00"<?php echo $can_write ? '' : ' disabled'; ?>>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>

        <h6 class="mt-3 mb-2">Hari Libur</h6>
        <div class="table-responsive">
          <table class="table table-bordered mkp-holiday-table">
            <thead class="thead-light">
              <tr>
                <th style="width: 170px;">Tanggal</th>
                <th>Keterangan</th>
                <th style="width: 230px;">Lokasi</th>
                <th style="width: 95px;">Aksi</th>
              </tr>
            </thead>
            <tbody id="mkpHolidayRows">
              <?php if (empty($visitHolidays)) { ?>
                <tr>
                  <td><input type="date" class="form-control" name="holiday_date[]" value=""<?php echo $can_write ? '' : ' disabled'; ?>></td>
                  <td><input type="text" class="form-control" name="holiday_name[]" value="" placeholder="Contoh: Libur Nasional"<?php echo $can_write ? '' : ' disabled'; ?>></td>
                  <td>
                    <select class="form-control" name="holiday_location[]"<?php echo $can_write ? '' : ' disabled'; ?>>
                      <option value="all">Semua Lokasi</option>
                      <?php foreach ($scheduleLocations as $scheduleLocation) { ?>
                        <option value="<?php echo htmlspecialchars($scheduleLocation); ?>"><?php echo htmlspecialchars($scheduleLocation); ?></option>
                      <?php } ?>
                    </select>
                  </td>
                  <td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"<?php echo $can_write ? '' : ' disabled'; ?>>Hapus</button></td>
                </tr>
              <?php } else { ?>
                <?php foreach ($visitHolidays as $holidayRow) { ?>
                  <?php
                  $holidayDate = htmlspecialchars((string)($holidayRow['date'] ?? ''));
                  $holidayName = htmlspecialchars((string)($holidayRow['name'] ?? ''));
                  $holidayLocation = (string)($holidayRow['location'] ?? 'all');
                  ?>
                  <tr>
                    <td><input type="date" class="form-control" name="holiday_date[]" value="<?php echo $holidayDate; ?>"<?php echo $can_write ? '' : ' disabled'; ?>></td>
                    <td><input type="text" class="form-control" name="holiday_name[]" value="<?php echo $holidayName; ?>" placeholder="Contoh: Libur Nasional"<?php echo $can_write ? '' : ' disabled'; ?>></td>
                    <td>
                      <select class="form-control" name="holiday_location[]"<?php echo $can_write ? '' : ' disabled'; ?>>
                        <option value="all"<?php echo $holidayLocation === 'all' ? ' selected' : ''; ?>>Semua Lokasi</option>
                        <?php foreach ($scheduleLocations as $scheduleLocation) { ?>
                          <option value="<?php echo htmlspecialchars($scheduleLocation); ?>"<?php echo $holidayLocation === $scheduleLocation ? ' selected' : ''; ?>><?php echo htmlspecialchars($scheduleLocation); ?></option>
                        <?php } ?>
                      </select>
                    </td>
                    <td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"<?php echo $can_write ? '' : ' disabled'; ?>>Hapus</button></td>
                  </tr>
                <?php } ?>
              <?php } ?>
            </tbody>
          </table>
        </div>

        <div class="mkp-schedule-actions">
          <button type="button" id="mkpHolidayAdd" class="btn btn-light btn-sm"<?php echo $can_write ? '' : ' disabled'; ?>>Tambah Hari Libur</button>
          <?php if ($can_write) { ?>
            <button type="submit" class="btn btn-primary btn-sm">Simpan Jadwal Visitor</button>
          <?php } ?>
        </div>
      </form>
    </div>

    <script>
      (function () {
        var scheduleForm = document.getElementById('mkpScheduleForm');
        if (!scheduleForm) return;

        var canWrite = <?php echo $can_write ? 'true' : 'false'; ?>;
        var locationPicker = document.getElementById('mkpScheduleLocationPicker');
        var dayRowsContainer = document.getElementById('mkpScheduleDayRows');
        var holidayRows = document.getElementById('mkpHolidayRows');
        var holidayAddButton = document.getElementById('mkpHolidayAdd');
        var mapJsonField = document.getElementById('mkpScheduleMapJson');
        var dayLabels = <?php echo json_encode($dayLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?> || {};
        var dayKeys = Object.keys(dayLabels);
        var defaultDayTemplate = <?php echo $defaultDayScheduleJson ?: '{}'; ?> || {};
        var scheduleLocations = <?php echo $scheduleLocationsJson ?: '[]'; ?> || [];
        var scheduleMap = <?php echo $scheduleMapJson ?: '{}'; ?> || {};

        function cloneDefaultDayTemplate() {
          return JSON.parse(JSON.stringify(defaultDayTemplate));
        }

        function escapeHtml(value) {
          return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
        }

        function normalizeTime(value, fallbackValue) {
          var val = String(value || '').trim();
          if (!/^\d{2}:\d{2}$/.test(val)) return fallbackValue;
          var hour = parseInt(val.substring(0, 2), 10);
          var minute = parseInt(val.substring(3, 5), 10);
          if (isNaN(hour) || isNaN(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            return fallbackValue;
          }
          return (hour < 10 ? '0' : '') + hour + ':' + (minute < 10 ? '0' : '') + minute;
        }

        function ensureLocationSchedule(locationName) {
          if (!locationName) return;
          if (!scheduleMap[locationName] || typeof scheduleMap[locationName] !== 'object') {
            scheduleMap[locationName] = cloneDefaultDayTemplate();
            return;
          }

          dayKeys.forEach(function (dayKey) {
            if (!scheduleMap[locationName][dayKey] || typeof scheduleMap[locationName][dayKey] !== 'object') {
              scheduleMap[locationName][dayKey] = JSON.parse(JSON.stringify(defaultDayTemplate[dayKey] || {
                open: 1,
                open_time: '08:00',
                close_time: '16:00'
              }));
            } else {
              scheduleMap[locationName][dayKey].open = scheduleMap[locationName][dayKey].open ? 1 : 0;
              scheduleMap[locationName][dayKey].open_time = normalizeTime(
                scheduleMap[locationName][dayKey].open_time,
                '08:00'
              );
              scheduleMap[locationName][dayKey].close_time = normalizeTime(
                scheduleMap[locationName][dayKey].close_time,
                '16:00'
              );
            }
          });
        }

        function fillDayForm(locationName) {
          ensureLocationSchedule(locationName);
          var locationSchedule = scheduleMap[locationName] || cloneDefaultDayTemplate();
          dayKeys.forEach(function (dayKey) {
            var row = dayRowsContainer.querySelector('tr[data-day="' + dayKey + '"]');
            if (!row) return;
            var openCheckbox = row.querySelector('.mkp-day-open');
            var openInput = row.querySelector('.mkp-day-open-time');
            var closeInput = row.querySelector('.mkp-day-close-time');
            var config = locationSchedule[dayKey] || {open: 1, open_time: '08:00', close_time: '16:00'};

            if (openCheckbox) openCheckbox.checked = !!config.open;
            if (openInput) openInput.value = normalizeTime(config.open_time, '08:00');
            if (closeInput) closeInput.value = normalizeTime(config.close_time, '16:00');
          });
        }

        function saveCurrentLocationFromForm() {
          var locationName = locationPicker.value || '';
          if (!locationName) return;
          ensureLocationSchedule(locationName);

          dayKeys.forEach(function (dayKey) {
            var row = dayRowsContainer.querySelector('tr[data-day="' + dayKey + '"]');
            if (!row) return;
            var openCheckbox = row.querySelector('.mkp-day-open');
            var openInput = row.querySelector('.mkp-day-open-time');
            var closeInput = row.querySelector('.mkp-day-close-time');

            scheduleMap[locationName][dayKey] = {
              open: openCheckbox && openCheckbox.checked ? 1 : 0,
              open_time: normalizeTime(openInput ? openInput.value : '', '08:00'),
              close_time: normalizeTime(closeInput ? closeInput.value : '', '16:00')
            };
          });
        }

        function buildHolidayRow(dateValue, nameValue, locationValue) {
          var row = document.createElement('tr');
          var locationOptionsHtml = '<option value="all"' + (locationValue === 'all' ? ' selected' : '') + '>Semua Lokasi</option>';
          scheduleLocations.forEach(function (locationName) {
            var selected = locationName === locationValue ? ' selected' : '';
            locationOptionsHtml += '<option value="' + escapeHtml(locationName) + '"' + selected + '>' + escapeHtml(locationName) + '</option>';
          });

          row.innerHTML = ''
            + '<td><input type="date" class="form-control" name="holiday_date[]" value="' + escapeHtml(dateValue || '') + '"' + (canWrite ? '' : ' disabled') + '></td>'
            + '<td><input type="text" class="form-control" name="holiday_name[]" value="' + escapeHtml(nameValue || '') + '" placeholder="Contoh: Libur Nasional"' + (canWrite ? '' : ' disabled') + '></td>'
            + '<td><select class="form-control" name="holiday_location[]"' + (canWrite ? '' : ' disabled') + '>' + locationOptionsHtml + '</select></td>'
            + '<td><button type="button" class="btn btn-danger btn-sm mkp-holiday-remove"' + (canWrite ? '' : ' disabled') + '>Hapus</button></td>';

          return row;
        }

        if (locationPicker) {
          locationPicker.innerHTML = '';
          scheduleLocations.forEach(function (locationName, index) {
            var option = document.createElement('option');
            option.value = locationName;
            option.textContent = locationName;
            locationPicker.appendChild(option);
            ensureLocationSchedule(locationName);
          });

          if (scheduleLocations.length > 0) {
            locationPicker.value = scheduleLocations[0];
            fillDayForm(locationPicker.value);
          }

          locationPicker.addEventListener('change', function () {
            saveCurrentLocationFromForm();
            fillDayForm(locationPicker.value || '');
          });
        }

        if (dayRowsContainer) {
          dayRowsContainer.addEventListener('change', function () {
            saveCurrentLocationFromForm();
          });
          dayRowsContainer.addEventListener('input', function () {
            saveCurrentLocationFromForm();
          });
        }

        if (holidayRows) {
          holidayRows.addEventListener('click', function (event) {
            var removeButton = event.target.closest('.mkp-holiday-remove');
            if (!removeButton) return;
            var row = removeButton.closest('tr');
            if (!row) return;
            row.remove();
            if (holidayRows.querySelectorAll('tr').length < 1) {
              holidayRows.appendChild(buildHolidayRow('', '', 'all'));
            }
          });
        }

        if (holidayAddButton) {
          holidayAddButton.addEventListener('click', function () {
            if (!holidayRows) return;
            holidayRows.appendChild(buildHolidayRow('', '', locationPicker && locationPicker.value ? locationPicker.value : 'all'));
          });
        }

        scheduleForm.addEventListener('submit', function () {
          saveCurrentLocationFromForm();
          if (mapJsonField) {
            mapJsonField.value = JSON.stringify(scheduleMap || {});
          }
        });
      })();
    </script>
    <?php } ?>

    <div class="d-flex justify-content-between align-items-center">
      <div class="text-muted small">
        <?php echo __('Showing'); ?> <?php echo $totalRows > 0 ? ($offset + 1) : 0; ?>-<?php echo min($offset + $perPage, $totalRows); ?> <?php echo __('of'); ?> <?php echo $totalRows; ?>
      </div>
      <nav>
        <ul class="pagination mb-0">
          <li class="page-item<?php echo $page <= 1 ? ' disabled' : ''; ?>">
            <a class="page-link" href="<?php echo $buildUrl(['page' => max(1, $page - 1)]); ?>">&laquo;</a>
          </li>
          <?php
          $startPage = max(1, $page - 2);
          $endPage = min($totalPages, $page + 2);
          for ($i = $startPage; $i <= $endPage; $i++) {
          ?>
            <li class="page-item<?php echo $i === $page ? ' active' : ''; ?>">
              <a class="page-link" href="<?php echo $buildUrl(['page' => $i]); ?>"><?php echo $i; ?></a>
            </li>
          <?php } ?>
          <li class="page-item<?php echo $page >= $totalPages ? ' disabled' : ''; ?>">
            <a class="page-link" href="<?php echo $buildUrl(['page' => min($totalPages, $page + 1)]); ?>">&raquo;</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</div>
