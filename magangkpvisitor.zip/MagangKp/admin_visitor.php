<?php
/**
 * Backward-compatible entry point for old admin menu URL.
 */
require __DIR__ . '/kelola_visitor_lengkap.php';
