<?php
/**
 * @Author: Faisal Fajar, Irsyad, Sena
 * @Date: 2026-02-27
 */

// Mencegah akses langsung ke file view
if (!defined('INDEX_AUTH')) {
    die("Akses langsung tidak diizinkan.");
}

// Data yang dibutuhkan dari controller/logic
// $sysconf, $page_title, $main_content (akan diisi via ob_start)
?>
<style>
    .visitor-container {
        max-width: 800px;
        margin: 2rem auto;
        padding: 2rem;
        background: #fff;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        font-family: inherit;
    }
    .visitor-container h2 {
        text-align: center;
        margin-bottom: 2rem;
        font-weight: 700;
        color: #333;
    }
    .form-group {
        position: relative;
        margin-bottom: 25px;
    }
    .form-group label {
        display: block;
        font-size: 0.9rem;
        font-weight: 600;
        margin-top: 5px;
        color: #666;
    }
    .form-control.input-lg {
        height: auto;
        padding: 12px 15px;
        font-size: 1.1rem;
        border-radius: 8px;
        border: 2px solid #e0e0e0;
        transition: border-color 0.3s;
    }
    .form-control.input-lg:focus {
        border-color: #007bff;
        box-shadow: none;
        outline: none;
    }
    #counterInfo {
        margin-top: 20px;
        padding: 15px;
        border-radius: 8px;
        text-align: center;
        font-weight: 600;
        display: none;
    }
    /* SLiMS compatibility */
    .row { display: flex; flex-wrap: wrap; margin-right: -15px; margin-left: -15px; }
    .col-lg-12, .col-lg-6 { position: relative; width: 100%; padding-right: 15px; padding-left: 15px; }
    @media (min-width: 992px) {
        .col-lg-12 { flex: 0 0 100%; max-width: 100%; }
        .col-lg-6 { flex: 0 0 50%; max-width: 50%; }
    }
</style>

<div class="visitor-container">
    <h2><?php echo __('Visitor Counter'); ?></h2>
    
    <form action="index.php?p=visitor" name="visitorCounterForm" id="visitorCounterForm" method="post">
      <div class="row">
        <div class="col-lg-12">
          <div class="form-group">
            <select id="visitorType" name="visitorType" class="form-control input-lg" style="margin-bottom: 20px;">
              <option value="member">Anggota</option>
              <option value="non_member">Non Anggota</option>
              <option value="rombongan">Rombongan</option>
            </select>
            <label>Tipe Pengunjung</label>
          </div>
        </div>

        <div class="col-lg-12" id="boxMemberID">
          <div class="form-group">
            <input type="text" name="memberID" id="memberID" class="form-control input-lg" required />
            <label for="memberID" id="labelMemberID"><?php echo __('Member ID / Visitor Name'); ?></label>
          </div>
        </div>

        <div class="col-lg-6" id="boxInstitution" style="display: none;">
          <div class="form-group">
            <input type="text" name="institution" id="institution" class="form-control input-lg" />
            <label for="institution"><?php echo __('Institution'); ?></label>
          </div>
        </div>

        <div class="col-lg-6" id="boxGroupCount" style="display: none;">
          <div class="form-group">
            <input type="number" name="groupCount" id="groupCount" class="form-control input-lg" value="1" min="1" />
            <label for="groupCount">Jumlah Rombongan</label>
          </div>
        </div>

        <div class="col-lg-12">
          <input type="submit" id="counter" name="counter" class="btn btn-primary btn-block btn-lg" style="width: 100%; padding: 15px;" value="<?php echo __('Add'); ?>">
        </div>
      </div>
    </form>
    
    <div id="counterInfo"></div>
</div>

<script>
$(document).ready(function() {
    // Pengaturan dinamis tampilan form berdasarkan tipe pengunjung
    $('#visitorType').on('change', function() {
        var visitorType = $(this).val();
        var boxInstitution = $('#boxInstitution');
        var boxMemberID = $('#boxMemberID');
        var boxGroupCount = $('#boxGroupCount');
        var labelMemberID = $('#labelMemberID');

        if (visitorType === 'non_member') {
            boxInstitution.show();
            boxGroupCount.hide();
            boxMemberID.removeClass('col-lg-12').addClass('col-lg-6');
            labelMemberID.text("<?php echo __('Member ID / Visitor Name'); ?>");
        } else if (visitorType === 'rombongan') {
            boxInstitution.show();
            boxGroupCount.show();
            boxMemberID.removeClass('col-lg-12').addClass('col-lg-6');
            labelMemberID.text("Nama Ketua Rombongan");
        } else {
            boxInstitution.hide();
            boxGroupCount.hide();
            boxMemberID.removeClass('col-lg-6').addClass('col-lg-12');
            labelMemberID.text("<?php echo __('Member ID / Visitor Name'); ?>");
        }
    });

    // Handle pengiriman form via AJAX
    $('#visitorCounterForm').on('submit', function(e) {
        e.preventDefault();
        var theForm = $(this);
        var formData = theForm.serialize();
        formData += '&counter=true';
        
        $('#counterInfo').fadeOut();
        theForm.find('input[type=submit]').prop('disabled', true).val('Mohon tunggu...');

        $.ajax({
            url: theForm.attr('action'),
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(respond) {
                $('#counterInfo').html(respond.message).fadeIn();
                if (respond.status === false) {
                    $('#counterInfo').css({'background': '#f8d7da', 'color': '#721c24'});
                } else {
                    $('#counterInfo').css({'background': '#d4edda', 'color': '#155724'});
                    theForm.find('input[type=text], input[type=number]').val(function(i, val) {
                        return this.id === 'groupCount' ? 1 : '';
                    });
                }
                setTimeout(() => {
                    theForm.find('input[type=submit]').prop('disabled', false).val('<?php echo __('Add'); ?>');
                    $('#memberID').focus();
                }, 500);
            },
            error: function() {
                $('#counterInfo').text('Terjadi kesalahan saat memproses data').fadeIn().css({'background': '#f8d7da', 'color': '#721c24'});
                theForm.find('input[type=submit]').prop('disabled', false).val('<?php echo __('Add'); ?>');
            }
        });
    });
});
</script>
